package com.zybooks.inventoryapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText newItemNameText;
    private EditText newItemQuantityText;
    private Button saveItemButton;
    private Button cancelItemButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        newItemNameText =
                findViewById(R.id.newItemNameText);

        newItemQuantityText =
                findViewById(R.id.newItemQuantityText);

        saveItemButton =
                findViewById(R.id.saveItemButton);

        cancelItemButton =
                findViewById(R.id.cancelItemButton);

        databaseHelper = new DatabaseHelper(this);

        saveItemButton.setOnClickListener(view ->
                saveItem());

        cancelItemButton.setOnClickListener(view ->
                finish());
    }

    // Save a new inventory item
    private void saveItem() {

        String itemName =
                newItemNameText.getText().toString();

        String quantityText =
                newItemQuantityText.getText().toString();

        if (itemName.isEmpty() || quantityText.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter an item name and quantity.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        int quantity = Integer.parseInt(quantityText);

        boolean itemAdded =
                databaseHelper.addItem(itemName, quantity);

        if (itemAdded) {

            Toast.makeText(
                    this,
                    "Item added.",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Unable to add item.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}