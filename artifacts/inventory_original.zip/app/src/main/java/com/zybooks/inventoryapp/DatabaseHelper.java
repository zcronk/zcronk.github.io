package com.zybooks.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";

    // Users table
    private static final String USERS_TABLE = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    // Inventory table
    private static final String INVENTORY_TABLE = "inventory";
    private static final String ITEM_ID = "id";
    private static final String ITEM_NAME = "name";
    private static final String ITEM_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE " + USERS_TABLE + " (" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME + " TEXT UNIQUE, " +
                        PASSWORD + " TEXT)";

        String createInventoryTable =
                "CREATE TABLE " + INVENTORY_TABLE + " (" +
                        ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ITEM_NAME + " TEXT, " +
                        ITEM_QUANTITY + " INTEGER)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    // Create a new user
    public boolean createUser(String username, String password) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        long result = db.insert(USERS_TABLE, null, values);

        return result != -1;
    }

    // Check if a username already exists
    public boolean userExists(String username) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                USERS_TABLE,
                null,
                USERNAME + "=?",
                new String[]{username},
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        return exists;
    }

    // Check username and password for login
    public boolean checkLogin(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                USERS_TABLE,
                null,
                USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, password},
                null,
                null,
                null
        );

        boolean found = cursor.getCount() > 0;
        cursor.close();

        return found;
    }

    // Add an inventory item
    public boolean addItem(String name, int quantity) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_NAME, name);
        values.put(ITEM_QUANTITY, quantity);

        long result = db.insert(INVENTORY_TABLE, null, values);

        return result != -1;
    }

    // View all inventory items
    public Cursor getAllItems() {

        SQLiteDatabase db = getReadableDatabase();

        return db.query(
                INVENTORY_TABLE,
                null,
                null,
                null,
                null,
                null,
                ITEM_NAME + " ASC"
        );
    }

    // Change an item's quantity
    public boolean updateQuantity(int id, int quantity) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ITEM_QUANTITY, quantity);

        int result = db.update(
                INVENTORY_TABLE,
                values,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }

    // Remove an inventory item
    public boolean deleteItem(int id) {

        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                INVENTORY_TABLE,
                ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        return result > 0;
    }
}