package com.zybooks.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private RecyclerView inventoryRecyclerView;
    private Button addItemButton;
    private Button notificationButton;

    private DatabaseHelper databaseHelper;

    private ArrayList<InventoryItem> inventoryItems;
    private InventoryList inventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryRecyclerView =
                findViewById(R.id.inventoryRecyclerView);

        addItemButton =
                findViewById(R.id.addItemButton);

        notificationButton =
                findViewById(R.id.notificationButton);

        databaseHelper = new DatabaseHelper(this);

        inventoryItems = new ArrayList<>();

        inventoryRecyclerView.setLayoutManager(
                new LinearLayoutManager(this)
        );

        addItemButton.setOnClickListener(view -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    AddItemActivity.class
            );

            startActivity(intent);
        });

        notificationButton.setOnClickListener(view -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    NotificationActivity.class
            );

            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        loadInventory();
    }

    // Load inventory records from the database
    private void loadInventory() {

        inventoryItems.clear();

        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.moveToFirst()) {

            do {

                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow("id")
                );

                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow("name")
                );

                int quantity = cursor.getInt(
                        cursor.getColumnIndexOrThrow("quantity")
                );

                inventoryItems.add(
                        new InventoryItem(id, name, quantity)
                );

            } while (cursor.moveToNext());
        }

        cursor.close();

        inventoryList =
                new InventoryList(
                        inventoryItems,
                        databaseHelper
                );

        inventoryRecyclerView.setAdapter(
                inventoryList
        );
    }
}