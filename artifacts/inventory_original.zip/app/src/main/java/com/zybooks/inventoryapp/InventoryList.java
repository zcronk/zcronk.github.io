package com.zybooks.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

public class InventoryList
        extends RecyclerView.Adapter<InventoryList.InventoryViewHolder> {

    private ArrayList<InventoryItem> inventoryItems;
    private DatabaseHelper databaseHelper;

    public InventoryList(ArrayList<InventoryItem> inventoryItems,
                         DatabaseHelper databaseHelper) {

        this.inventoryItems = inventoryItems;
        this.databaseHelper = databaseHelper;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.inventory_row, parent, false);

        return new InventoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull InventoryViewHolder holder, int position) {

        InventoryItem item = inventoryItems.get(position);

        holder.itemNameText.setText(item.getName());
        holder.itemQuantityText.setText(
                String.valueOf(item.getQuantity())
        );

        // Increase the item's quantity
        holder.increaseButton.setOnClickListener(view -> {

            int newQuantity = item.getQuantity() + 1;

            databaseHelper.updateQuantity(
                    item.getId(), newQuantity);

            item.setQuantity(newQuantity);

            notifyItemChanged(position);
        });

        // Decrease the item's quantity
        holder.decreaseButton.setOnClickListener(view -> {

            if (item.getQuantity() > 0) {

                int newQuantity = item.getQuantity() - 1;

                databaseHelper.updateQuantity(
                        item.getId(), newQuantity
                );

                item.setQuantity(newQuantity);

                notifyItemChanged(position);

                // Send SMS notification if quantity reaches zero
                if (newQuantity == 0) {
                    sendLowInventorySms(
                            view.getContext(),
                            item.getName()
                    );
                }
            }
        });

        // Delete the item
        holder.deleteItemButton.setOnClickListener(view -> {

            databaseHelper.deleteItem(item.getId());

            inventoryItems.remove(position);

            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return inventoryItems.size();
    }

    private void sendLowInventorySms(
            Context context,
            String itemName) {

        SharedPreferences preferences =
                context.getSharedPreferences(
                        "notification_settings",
                        Context.MODE_PRIVATE
                );

        boolean smsEnabled =
                preferences.getBoolean(
                        "sms_enabled",
                        false
                );

        String phoneNumber =
                preferences.getString(
                        "phone_number",
                        ""
                );

        // Do nothing if SMS notifications are disabled
        if (!smsEnabled || phoneNumber.isEmpty()) {
            return;
        }

        // Do nothing if permission was not granted
        if (ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        String message =
                "Inventory Alert: " +
                        itemName +
                        " has reached zero quantity.";

        SmsManager smsManager =
                context.getSystemService(SmsManager.class);

        smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null
        );
    }

    public static class InventoryViewHolder
            extends RecyclerView.ViewHolder {

        TextView itemNameText;
        TextView itemQuantityText;
        Button increaseButton;
        Button decreaseButton;
        Button deleteItemButton;

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);

            itemNameText =
                    itemView.findViewById(R.id.itemNameText);

            itemQuantityText =
                    itemView.findViewById(R.id.itemQuantityText);

            increaseButton =
                    itemView.findViewById(R.id.increaseButton);

            decreaseButton =
                    itemView.findViewById(R.id.decreaseButton);

            deleteItemButton =
                    itemView.findViewById(R.id.deleteItemButton);
        }
    }
}