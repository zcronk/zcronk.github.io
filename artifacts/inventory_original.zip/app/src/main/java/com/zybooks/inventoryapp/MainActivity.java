package com.zybooks.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameText;
    private EditText passwordText;
    private Button loginButton;
    private Button createAccountButton;
    private TextView loginStatusText;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        loginStatusText = findViewById(R.id.loginStatusText);

        databaseHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(view -> loginUser());

        createAccountButton.setOnClickListener(view -> createAccount());
    }

    // Check the entered username and password against the database
    private void loginUser() {

        String username = usernameText.getText().toString();
        String password = passwordText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            loginStatusText.setText("Enter a username and password.");
            return;
        }

        if (databaseHelper.checkLogin(username, password)) {

            Intent intent = new Intent(
                    MainActivity.this,
                    InventoryActivity.class
            );

            startActivity(intent);

        } else {
            loginStatusText.setText("Invalid username or password.");
        }
    }

    // Create and save a new user account
    private void createAccount() {

        String username = usernameText.getText().toString();
        String password = passwordText.getText().toString();

        if (username.isEmpty() || password.isEmpty()) {
            loginStatusText.setText("Enter a username and password.");
            return;
        }

        if (databaseHelper.userExists(username)) {
            loginStatusText.setText("Username already exists.");
            return;
        }

        boolean accountCreated =
                databaseHelper.createUser(username, password);

        if (accountCreated) {
            loginStatusText.setText("Account created. You can now log in.");
        } else {
            loginStatusText.setText("Unable to create account.");
        }
    }
}