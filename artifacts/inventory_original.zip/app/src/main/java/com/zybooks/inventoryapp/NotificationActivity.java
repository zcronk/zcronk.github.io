package com.zybooks.inventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity {

    private EditText phoneNumberText;
    private Button enableSmsButton;
    private Button continueWithoutSmsButton;
    private TextView permissionStatusText;

    private SharedPreferences preferences;

    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        phoneNumberText =
                findViewById(R.id.phoneNumberText);

        enableSmsButton =
                findViewById(R.id.enableSmsButton);

        continueWithoutSmsButton =
                findViewById(R.id.continueWithoutSmsButton);

        permissionStatusText =
                findViewById(R.id.permissionStatusText);

        preferences = getSharedPreferences(
                "notification_settings",
                MODE_PRIVATE
        );

        // Load previously saved phone number
        String savedPhoneNumber =
                preferences.getString("phone_number", "");

        phoneNumberText.setText(savedPhoneNumber);

        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {

                    if (isGranted) {

                        saveNotificationSettings();

                        permissionStatusText.setText(
                                "SMS notifications enabled"
                        );

                    } else {

                        preferences.edit()
                                .putBoolean("sms_enabled", false)
                                .apply();

                        permissionStatusText.setText(
                                "SMS permission denied"
                        );
                    }
                });

        enableSmsButton.setOnClickListener(view ->
                enableSmsNotifications());

        continueWithoutSmsButton.setOnClickListener(view -> {

            preferences.edit()
                    .putBoolean("sms_enabled", false)
                    .apply();

            finish();
        });

        updatePermissionStatus();
    }

    private void enableSmsNotifications() {

        String phoneNumber =
                phoneNumberText.getText().toString();

        if (phoneNumber.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter a phone number.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            saveNotificationSettings();

            permissionStatusText.setText(
                    "SMS notifications enabled"
            );

        } else {

            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    private void saveNotificationSettings() {

        String phoneNumber =
                phoneNumberText.getText().toString();

        preferences.edit()
                .putString("phone_number", phoneNumber)
                .putBoolean("sms_enabled", true)
                .apply();
    }

    private void updatePermissionStatus() {

        boolean enabled =
                preferences.getBoolean(
                        "sms_enabled",
                        false
                );

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED
                && enabled) {

            permissionStatusText.setText(
                    "SMS notifications enabled"
            );

        } else {

            permissionStatusText.setText(
                    "SMS notifications not enabled"
            );
        }
    }
}